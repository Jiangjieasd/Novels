package com.guuidea.inreading.model.flag;

/**
 * Created by guuidea on 17-4-24.
 * 转换显示的名字和网络中的名字
 */

interface BookConvert {
    String getTypeName();
    String getNetName();
}
