package com.guuidea.inreading.event;

/**
 * Created by guuidea on 17-5-8.
 */

public class RecommendBookEvent {
    public String sex;

    public RecommendBookEvent(String sex){
        this.sex = sex;
    }
}
