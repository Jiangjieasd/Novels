package com.guuidea.inreading.widget.page;

import java.util.List;

/**
 * Created by guuidea on 17-7-1.
 */

public class TxtPage {
    int position;
    String title;
    int titleLines; //当前 lines 中为 title 的行数。
    List<String> lines;
}
