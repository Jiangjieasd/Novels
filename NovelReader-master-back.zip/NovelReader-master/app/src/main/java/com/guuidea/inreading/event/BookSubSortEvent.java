package com.guuidea.inreading.event;

/**
 * Created by guuidea on 17-5-5.
 */

public class BookSubSortEvent {
    public String bookSubSort;

    public BookSubSortEvent(String bookSubSort){
        this.bookSubSort = bookSubSort;
    }
}
