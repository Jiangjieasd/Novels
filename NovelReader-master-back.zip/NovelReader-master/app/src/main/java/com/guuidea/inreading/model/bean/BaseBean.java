package com.guuidea.inreading.model.bean;

/**
 * Created by guuidea on 17-4-20.
 */

public class BaseBean {
  public boolean ok;
}

