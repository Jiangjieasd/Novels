package com.guuidea.inreading.model.local;

/**
 * Created by guuidea on 17-5-27.
 */

public final class Void {
}
